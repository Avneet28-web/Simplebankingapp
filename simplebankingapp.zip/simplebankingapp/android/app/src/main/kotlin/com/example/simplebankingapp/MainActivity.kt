package com.example.simplebankingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
